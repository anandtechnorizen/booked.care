const ToolbarActions = ({
  children
}) => {
  return <div className="flex items-center gap-1">{children}</div>;
};
export { ToolbarActions };