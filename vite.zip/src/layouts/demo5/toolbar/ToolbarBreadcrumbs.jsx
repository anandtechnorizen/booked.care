import { Fragment } from 'react';
import { useLocation } from 'react-router';
import { Link } from 'react-router-dom';
import { useMenuBreadcrumbs } from '@/components';
import { useMenus } from '@/providers';
const ToolbarBreadcrumbs = () => {
  const {
    getMenuConfig
  } = useMenus();
  const {
    pathname
  } = useLocation();
  const items = useMenuBreadcrumbs(pathname, getMenuConfig('primary'));
  return <div className="flex items-center gap-1 text-sm font-normal">
      {items.map((item, index) => <Fragment key={index}>
          {item.path ? <Link to={item.path} className="text-gray-700 hover:text-primary">
              {item.title}
            </Link> : <span className={index === items.length - 1 ? 'text-gray-900' : 'text-gray-700'}>
              {item.title}
            </span>}
          {index !== items.length - 1 && <span className="text-gray-400 text-sm">/</span>}
        </Fragment>)}
    </div>;
};
export { ToolbarBreadcrumbs };