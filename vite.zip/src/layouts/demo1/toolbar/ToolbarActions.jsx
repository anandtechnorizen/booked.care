const ToolbarActions = ({
  children
}) => {
  return <div className="flex items-center gap-2.5">{children}</div>;
};
export { ToolbarActions };