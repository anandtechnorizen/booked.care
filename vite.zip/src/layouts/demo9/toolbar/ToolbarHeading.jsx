import { useLocation } from 'react-router';
import { useMenus } from '@/providers';
import { useMenuCurrentItem } from '@/components';
import { ToolbarBreadcrumbs } from '.';
const ToolbarHeading = ({
  title = ''
}) => {
  const {
    getMenuConfig
  } = useMenus();
  const {
    pathname
  } = useLocation();
  const currentMenuItem = useMenuCurrentItem(pathname, getMenuConfig('primary'));
  return <div className="flex flex-col justify-center items-start flex-wrap gap-1 lg:gap-2">
      <h1 className="font-medium text-lg text-gray-900">{title || currentMenuItem?.title}</h1>
      <div className="flex items-center gap-1 text-sm font-normal">
        <ToolbarBreadcrumbs />
      </div>
    </div>;
};
export { ToolbarHeading };